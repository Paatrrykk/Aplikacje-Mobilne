package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {

    private EditText editTextProductName;
    private EditText editTextPrice;
    private EditText editTextDescription;
    private Button addButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        editTextProductName = findViewById(R.id.product_name);
        editTextPrice = findViewById(R.id.price);
        editTextDescription = findViewById(R.id.description);
        addButton = findViewById(R.id.add_button);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addItem();
            }
        });
    }

    private void addItem() {
        String productName = editTextProductName.getText().toString();
        String price = editTextPrice.getText().toString();
        String description = editTextDescription.getText().toString();

        if (productName.isEmpty() || price.isEmpty() || description.isEmpty()) {
            Toast.makeText(this, "Proszę uzupełnić wszystkie pola", Toast.LENGTH_SHORT).show();
            return;
        }

        DatabaseHelper dbHelper = new DatabaseHelper(this);
        dbHelper.addItem(new Item(productName, Double.parseDouble(price), description));

        Toast.makeText(this, "Dodano produkt", Toast.LENGTH_SHORT).show();
        finish();
    }
}
