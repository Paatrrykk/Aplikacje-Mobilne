package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EditItemActivity extends AppCompatActivity {

    private EditText editTextProductName;
    private EditText editTextPrice;
    private EditText editTextDescription;
    private Button updateButton;
    private Button deleteButton;

    private Item item;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);

        editTextProductName = findViewById(R.id.product_name);
        editTextPrice = findViewById(R.id.price);
        editTextDescription = findViewById(R.id.description);
        updateButton = findViewById(R.id.update_button);
        deleteButton = findViewById(R.id.delete_button);

        // Retrieve the item from the intent
        item = (Item) getIntent().getSerializableExtra("item");
        if (item != null) {
            editTextProductName.setText(item.getName());
            editTextPrice.setText(String.valueOf(item.getPrice()));
            editTextDescription.setText(item.getDescription());
        }

        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateItem();
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteItem();
            }
        });
    }

    private void updateItem() {
        String productName = editTextProductName.getText().toString();
        String priceString = editTextPrice.getText().toString();
        String description = editTextDescription.getText().toString();

        if (productName.isEmpty() || priceString.isEmpty() || description.isEmpty()) {
            Toast.makeText(this, "Proszę uzupełnić wszystkie pola", Toast.LENGTH_SHORT).show();
            return;
        }

        double price = Double.parseDouble(priceString);
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        item.setName(productName);
        item.setPrice(price);
        item.setDescription(description);
        dbHelper.updateItem(item);

        Toast.makeText(this, "Element zaktualizowany", Toast.LENGTH_SHORT).show();
        finish();
    }

    private void deleteItem() {
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        dbHelper.deleteItem(item.getId());
        Toast.makeText(this, "Element usunięty", Toast.LENGTH_SHORT).show();
        finish();
    }
}
