package com.example.myapplication;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class ListActivity extends AppCompatActivity {

    private ListView listView;
    private ItemAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        listView = findViewById(R.id.listView);
        loadItems();
    }

    private void loadItems() {
        new LoadItemsTask().execute();
    }

    private class LoadItemsTask extends AsyncTask<Void, Void, List<Item>> {
        @Override
        protected List<Item> doInBackground(Void... voids) {
            DatabaseHelper dbHelper = new DatabaseHelper(ListActivity.this);
            return dbHelper.getAllItems();
        }

        @Override
        protected void onPostExecute(List<Item> items) {
            adapter = new ItemAdapter(ListActivity.this, items);
            listView.setAdapter(adapter);
        }
    }
}
