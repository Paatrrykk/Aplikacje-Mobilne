package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText editTextProductName;
    private EditText editTextPrice;
    private EditText editTextDescription;
    private Button addButton;
    private Button showAllButton;
    private ListView listView;

    private DatabaseHelper dbHelper;
    private ItemAdapter adapter;
    private ArrayList<Item> itemList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextProductName = findViewById(R.id.product_name);
        editTextPrice = findViewById(R.id.price);
        editTextDescription = findViewById(R.id.description);
        addButton = findViewById(R.id.add_button);
        showAllButton = findViewById(R.id.show_all_button);
        listView = findViewById(R.id.listView);

        dbHelper = new DatabaseHelper(this);
        itemList = new ArrayList<>();
        adapter = new ItemAdapter(this, itemList);
        listView.setAdapter(adapter);

        // Umożliwienie dodawania elementów
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addItem();
            }
        });

        // Umożliwienie pokazywania wszystkich elementów
        showAllButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAllItems();
            }
        });
    }

    private void addItem() {
        String productName = editTextProductName.getText().toString();
        String priceString = editTextPrice.getText().toString();
        String description = editTextDescription.getText().toString();

        if (productName.isEmpty() || priceString.isEmpty() || description.isEmpty()) {
            Toast.makeText(this, "Proszę uzupełnić wszystkie pola", Toast.LENGTH_SHORT).show();
            return;
        }

        double price = Double.parseDouble(priceString);
        DatabaseHelper dbHelper = new DatabaseHelper(this);

        // Tworzenie nowego elementu bez ID
        Item newItem = new Item(productName, price, description);
        long newId = dbHelper.addItem(newItem); // Zapisz element i uzyskaj ID
        newItem.setId((int) newId); // Ustaw ID w obiekcie

        itemList.add(newItem); // Dodaj element do listy
        adapter.notifyDataSetChanged(); // Powiadom adapter o zmianach

        Toast.makeText(this, "Element dodany", Toast.LENGTH_SHORT).show();
    }

    private void showAllItems() {
        itemList.clear(); // Wyczyść obecną listę
        itemList.addAll(dbHelper.getAllItems()); // Pobierz wszystkie elementy z bazy danych
        adapter.notifyDataSetChanged(); // Powiadom adapter o zmianach

        Toast.makeText(this, "Pobrano wszystkie elementy", Toast.LENGTH_SHORT).show();
    }
}
