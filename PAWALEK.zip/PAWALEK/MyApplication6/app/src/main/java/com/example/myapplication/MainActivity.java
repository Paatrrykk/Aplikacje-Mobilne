package com.example.myapplication;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private ImageView imageView;
    private TextView textViewBitmapSize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.imageView);
        Button buttonCreateBitmap = findViewById(R.id.buttonCreateBitmap);
        Button buttonConvertToMonochrome = findViewById(R.id.buttonConvertToMonochrome);
        textViewBitmapSize = findViewById(R.id.textViewBitmapSize);

        buttonCreateBitmap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createBitmap();
            }
        });

        buttonConvertToMonochrome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convertToMonochrome();
            }
        });
    }

    private void createBitmap() {
        Drawable drawable = imageView.getDrawable();

        if (drawable != null) {
            Bitmap originalBitmap = drawableToBitmap(drawable);

            int width = originalBitmap.getWidth();
            int height = originalBitmap.getHeight();
            textViewBitmapSize.setText(width + "x" + height);
        } else {
            textViewBitmapSize.setText("Błąd: obrazek nie jest dostępny.");
        }
    }

    private void convertToMonochrome() {
        Drawable drawable = imageView.getDrawable();

        if (drawable != null) {
            Bitmap originalBitmap = drawableToBitmap(drawable);

            Bitmap monochromeBitmap = Bitmap.createBitmap(originalBitmap.getWidth(), originalBitmap.getHeight(), Bitmap.Config.ARGB_8888);
            for (int x = 0; x < originalBitmap.getWidth(); x++) {
                for (int y = 0; y < originalBitmap.getHeight(); y++) {
                    int pixel = originalBitmap.getPixel(x, y);
                    int gray = (int) (Color.red(pixel) * 0.299 + Color.green(pixel) * 0.587 + Color.blue(pixel) * 0.114);
                    monochromeBitmap.setPixel(x, y, Color.rgb(gray, gray, gray));
                }
            }

            imageView.setImageBitmap(monochromeBitmap);

            imageView.setImageBitmap(monochromeBitmap);

        } else {
            textViewBitmapSize.setText("Błąd: obrazek nie jest dostępny.");
        }
    }

    private Bitmap drawableToBitmap(Drawable drawable) {
        if (drawable instanceof BitmapDrawable) {
            return ((BitmapDrawable) drawable).getBitmap();
        }

        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        android.graphics.Canvas canvas = new android.graphics.Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);
        return bitmap;
    }
}
