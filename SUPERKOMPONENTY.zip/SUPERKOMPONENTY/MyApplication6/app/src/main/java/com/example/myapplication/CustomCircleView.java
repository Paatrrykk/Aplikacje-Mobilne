package com.example.myapplication;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class CustomCircleView extends View {
    private Paint paint;
    private float radius = 100f;
    private int circleColor = Color.RED;
    private float cx = 200f;
    private float cy = 200f;
    private final float radiusIncrement = 5f;
    private boolean isDragging = false;

    public CustomCircleView(Context context) {
        super(context);
        init();
    }

    public CustomCircleView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public CustomCircleView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        paint = new Paint();
        paint.setColor(circleColor);
        paint.setAntiAlias(true);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawCircle(cx, cy, radius, paint);
    }

    public void setCircleColor(int color) {
        this.circleColor = color;
        paint.setColor(circleColor);
        invalidate();
    }

    public void setCircleRadius(float radius) {
        this.radius = radius;
        invalidate();
    }

    public void setCirclePosition(float x, float y) {
        this.cx = x;
        this.cy = y;
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float touchX = event.getX();
        float touchY = event.getY();

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                if (isInsideCircle(touchX, touchY)) {
                    isDragging = true;
                    animateCircleRadiusIncrease();
                    setCircleColor(Color.rgb((int) (Math.random() * 256), (int) (Math.random() * 256), (int) (Math.random() * 256)));
                    return true;
                }
                break;

            case MotionEvent.ACTION_MOVE:
                if (isDragging) {
                    setCirclePosition(touchX, touchY);
                    return true;
                }
                break;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                isDragging = false;
                break;
        }

        return super.onTouchEvent(event);
    }

    private boolean isInsideCircle(float x, float y) {
        float dx = x - cx;
        float dy = y - cy;
        return (dx * dx + dy * dy) <= radius * radius;
    }

    private void animateCircleRadiusIncrease() {
        float newRadius = radius + radiusIncrement;
        ObjectAnimator animator = ObjectAnimator.ofFloat(this, "circleRadius", radius, newRadius);
        animator.setDuration(30);
        animator.start();
    }
}
