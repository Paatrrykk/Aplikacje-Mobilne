package com.example.myapplication;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.animation.ObjectAnimator;
import android.view.animation.LinearInterpolator;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CustomCircleView customCircleView = findViewById(R.id.customCircleView);

        customCircleView.setCircleRadius(150f);
        customCircleView.setCirclePosition(400f, 400f);


    }
}
