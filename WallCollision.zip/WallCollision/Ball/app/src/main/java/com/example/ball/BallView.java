package com.example.ball;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

import java.util.Random;

public class BallView extends View {
    private Random random;
    private Paint paint;
    private float x, y;
    private float radius;
    private double angle;
    private float speed;

    public BallView(Context context, float x, float y) {
        super(context);
        random = new Random();
        paint = new Paint();
        paint.setColor(Color.BLACK); // Ustawienie koloru na czarny
        this.x = x;
        this.y = y;
        radius = 50;
        angle = Math.random() * Math.PI * 2;
        speed = 10;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawCircle(x, y, radius, paint);
    }

    public void updateBallPosition() {

        float newX = (float) (x + speed * Math.cos(angle));
        float newY = (float) (y + speed * Math.sin(angle));

        if (newX - radius < 0 || newX + radius > getWidth()) {
            angle = Math.PI - angle;
            newX = Math.max(radius, Math.min(getWidth() - radius, newX));
        }
        if (newY - radius < 0 || newY + radius > getHeight()) {
            angle = -angle;
            newY = Math.max(radius, Math.min(getHeight() - radius, newY));
        }

        x = newX;
        y = newY;
        invalidate();
    }
}
