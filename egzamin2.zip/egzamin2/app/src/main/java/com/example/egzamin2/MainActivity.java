package com.example.egzamin2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private TextView resultTextView, gameResultTextView;
    private ImageView diceImage1, diceImage2, diceImage3, diceImage4, diceImage5;
    private Button rollButton, resetButton;
    private int gameResult = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        resultTextView = findViewById(R.id.resultTextView);
        gameResultTextView = findViewById(R.id.gameResultTextView);
        diceImage1 = findViewById(R.id.dice1);
        diceImage2 = findViewById(R.id.dice2);
        diceImage3 = findViewById(R.id.dice3);
        diceImage4 = findViewById(R.id.dice4);
        diceImage5 = findViewById(R.id.dice5);
        rollButton = findViewById(R.id.rollButton);
        resetButton = findViewById(R.id.resetButton);

        rollButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int[] diceResults = rollDice();
                updateDiceImages(diceResults);
                int roundResult = calculateSum(diceResults);
                resultTextView.setText("Wynik tego losowania: " + roundResult);
                gameResult += roundResult;
                gameResultTextView.setText("Wynik gry: " + gameResult);
            }
        });

        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetGame();
            }
        });
    }

    private int[] rollDice() {
        Random rand = new Random();
        int[] diceResults = new int[5];
        for (int i = 0; i < 5; i++) {
            diceResults[i] = rand.nextInt(6) + 1;
        }
        return diceResults;
    }

    private void updateDiceImages(int[] diceResults) {
        ImageView[] diceImages = {diceImage1, diceImage2, diceImage3, diceImage4, diceImage5};

        for (int i = 0; i < 5; i++) {
            String diceImageName = "dice" + diceResults[i];

            int diceResource = getResources().getIdentifier(diceImageName, "drawable", getPackageName());

            if (diceResource != 0) {
                diceImages[i].setImageResource(diceResource);
            } else {
                diceImages[i].setImageResource(R.drawable.znakzapytania);
            }
        }
    }


    private int calculateSum(int[] diceResults) {
        int sum = 0;
        for (int i : diceResults) {
            sum += i;
        }
        return sum;
    }

    private void resetGame() {
        diceImage1.setImageResource(R.drawable.znakzapytania);
        diceImage2.setImageResource(R.drawable.znakzapytania);
        diceImage3.setImageResource(R.drawable.znakzapytania);
        diceImage4.setImageResource(R.drawable.znakzapytania);
        diceImage5.setImageResource(R.drawable.znakzapytania);
        gameResult = 0;
        gameResultTextView.setText("Wynik gry: 0");
        resultTextView.setText("Wynik tego losowania: 0");
    }
}
