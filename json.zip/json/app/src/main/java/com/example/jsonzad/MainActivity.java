package com.example.jsonzad;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            String jsonString = "{\"info\":{\"przedmiot\":\"Aplikacje mobilne\",\"prowadzacy\":\"Marek Genge\",\"szkola\":\"Zespol Szkol Elektrycznych\",\"miasto\":\"Gorzow Wielkopolski\",\"dataczas\":\"2023-11-22 22:43\"},\"numer\":\"17\",\"imie\":\"Wawrzyniak Patryk\"}";

            LekcjaInfo lekcjaInfo = LekcjaInfo.fromJson(new JSONObject(jsonString).getJSONObject("info"));
            String numer = new JSONObject(jsonString).getString("numer");
            String imie = new JSONObject(jsonString).getString("imie");

            TextView textView = findViewById(R.id.textView);
            textView.setText("Przedmiot: " + lekcjaInfo.getPrzedmiot() +
                    "\nProwadzacy: " + lekcjaInfo.getProwadzacy() +
                    "\nSzkola: " + lekcjaInfo.getSzkola() +
                    "\nMiasto: " + lekcjaInfo.getMiasto() +
                    "\nData i czas: " + lekcjaInfo.getDataczas() +
                    "\nNumer: " + numer + "\nImie: " + imie);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private static class LekcjaInfo {
        private String przedmiot;
        private String prowadzacy;
        private String szkola;
        private String miasto;
        private String dataczas;

        private LekcjaInfo(String przedmiot, String prowadzacy, String szkola, String miasto, String dataczas) {
            this.przedmiot = przedmiot;
            this.prowadzacy = prowadzacy;
            this.szkola = szkola;
            this.miasto = miasto;
            this.dataczas = dataczas;
        }

        public static LekcjaInfo fromJson(JSONObject jsonObject) throws JSONException {
            String przedmiot = jsonObject.getString("przedmiot");
            String prowadzacy = jsonObject.getString("prowadzacy");
            String szkola = jsonObject.getString("szkola");
            String miasto = jsonObject.getString("miasto");
            String dataczas = jsonObject.getString("dataczas");

            return new LekcjaInfo(przedmiot, prowadzacy, szkola, miasto, dataczas);
        }

        public String getPrzedmiot() {
            return przedmiot;
        }

        public String getProwadzacy() {
            return prowadzacy;
        }

        public String getSzkola() {
            return szkola;
        }

        public String getMiasto() {
            return miasto;
        }

        public String getDataczas() {
            return dataczas;
        }
    }
}