package com.example.jsonzad;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONException;
import org.json.JSONObject;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            String jsonString = "{\"info\":{\"przedmiot\":\"Aplikacje mobilne\",\"prowadzacy\":\"Marek Genge\",\"szkola\":\"Zespol Szkol Elektrycznych\",\"miasto\":\"Gorzow Wielkopolski\",\"dataczas\":\"2023-11-22 22:43\"},\"numer\":\"17\",\"imie\":\"Wawrzyniak Patryk\"}";

            LessonInfo lessonInfo = LessonInfo.fromJson(new JSONObject(jsonString).getJSONObject("info"));
            String numer = new JSONObject(jsonString).getString("numer");
            String imie = new JSONObject(jsonString).getString("imie");

            TextView textView = findViewById(R.id.textView);
            textView.setText("Przedmiot: " + lessonInfo.getPrzedmiot() +
                    "\nProwadzacy: " + lessonInfo.getProwadzacy() +
                    "\nSzkola: " + lessonInfo.getSzkola() +
                    "\nMiasto: " + lessonInfo.getMiasto() +
                    "\nData i czas: " + lessonInfo.getDataczas() +
                    "\nNumer: " + numer + "\nImie: " + imie);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    private static class LessonInfo {
        private String przedmiot;
        private String prowadzacy;
        private String szkola;
        private String miasto;
        private LocalDateTime dataczas;

        private LessonInfo(String przedmiot, String prowadzacy, String szkola, String miasto, LocalDateTime dataczas) {
            this.przedmiot = przedmiot;
            this.prowadzacy = prowadzacy;
            this.szkola = szkola;
            this.miasto = miasto;
            this.dataczas = dataczas;
        }

        public static LessonInfo fromJson(JSONObject jsonObject) throws JSONException {
            String przedmiot = jsonObject.getString("przedmiot");
            String prowadzacy = jsonObject.getString("prowadzacy");
            String szkola = jsonObject.getString("szkola");
            String miasto = jsonObject.getString("miasto");
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            LocalDateTime dataczas = LocalDateTime.parse(jsonObject.getString("dataczas"), formatter);

            return new LessonInfo(przedmiot, prowadzacy, szkola, miasto, dataczas);
        }

        public String getPrzedmiot() {
            return przedmiot;
        }

        public String getProwadzacy() {
            return prowadzacy;
        }

        public String getSzkola() {
            return szkola;
        }

        public String getMiasto() {
            return miasto;
        }

        public String getDataczas() {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            return formatter.format(dataczas);
        }
    }
}