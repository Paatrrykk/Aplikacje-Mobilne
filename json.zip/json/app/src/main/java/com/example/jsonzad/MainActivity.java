package com.example.jsonzad;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            String jsonString = "{\"info\":{\"przedmiot\":\"Aplikacje mobilne\",\"prowadzacy\":\"Marek Genge\",\"szkola\":\"Zespol Szkol Elektrycznych\",\"miasto\":\"Gorzow Wielkopolski\",\"dataczas\":\"2023-11-22 22:43\"},\"numer\":\"17\",\"imie\":\"Wawrzyniak Patryk\"}";

            JSONObject jObject = new JSONObject(jsonString);

            JSONObject info = jObject.getJSONObject("info");
            String przedmiot = info.getString("przedmiot");
            String prowadzacy = info.getString("prowadzacy");
            String szkola = info.getString("szkola");
            String miasto = info.getString("miasto");
            String dataczas = info.getString("dataczas");
            String numer = jObject.getString("numer");
            String imie = jObject.getString("imie");

            TextView textView = findViewById(R.id.textView);
            textView.setText("Przedmiot: " + przedmiot + "\nProwadzacy: " + prowadzacy + "\nszkola: " + szkola + "\nmiasto: " + miasto + "\ndataczas: " + dataczas + "\nnumer: " + numer + "\nimie: " + imie);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
